import sys

# Windows only: tell Windows this is its own app, so the taskbar shows YOUR icon, not the Python logo
if sys.platform == "win32":
    import ctypes
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("daneesh.blockthebombs.game")
    except Exception:
        pass

import array
import math
import random
import pygame

pygame.mixer.pre_init(44100, -16, 1, 512)   # sound settings: must come BEFORE pygame.init()
pygame.init()

WIDTH, HEIGHT = 800, 600
HUD_HEIGHT = 70     # the top bar that holds the words
# Game icon: light blue background with the words BLOCK THE BOMBS in dark blue
icon = pygame.Surface((64, 64))
icon.fill((135, 206, 235))                                   # light blue
icon_font = pygame.font.SysFont(None, 22, bold=True)
for n, word in enumerate(["BLOCK", "THE", "BOMBS"]):
    word_image = icon_font.render(word, True, (10, 30, 120))  # dark blue letters
    icon.blit(word_image, word_image.get_rect(center=(32, 14 + n * 18)))
pygame.display.set_icon(icon)                                # must come BEFORE set_mode

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Block the Bombs! created by Daneesh using python and downloading pygame   2D game 1.0 version")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)
small_font = pygame.font.SysFont(None, 26)
big_font = pygame.font.SysFont(None, 72)

# ---------- SOUNDS (made by the code, so no sound files are needed) ----------
sound_ok = pygame.mixer.get_init() is not None and pygame.mixer.get_init()[1] == -16
if sound_ok:
    SAMPLE_RATE = pygame.mixer.get_init()[0]
    CHANNELS = pygame.mixer.get_init()[2]


def make_sound(parts, volume=0.5):
    # parts is a list of (frequency, seconds, kind) steps played one after another
    # kind: "tone" = a beep, "boom" = an explosion (noise + a low thump at freq Hz)
    samples = array.array("h")
    for freq, seconds, kind in parts:
        count = int(SAMPLE_RATE * seconds)
        for i in range(count):
            fade = 1 - i / count                       # gets quieter and quieter
            t = i / SAMPLE_RATE
            if kind == "boom":
                value = 0.6 * random.uniform(-1, 1) + 0.6 * math.sin(2 * math.pi * freq * t)
            else:
                value = math.sin(2 * math.pi * freq * t)
            sample = int(value * fade * 12000)
            for c in range(CHANNELS):
                samples.append(sample)
    sound = pygame.mixer.Sound(buffer=samples.tobytes())
    sound.set_volume(volume)
    return sound


if sound_ok:
    click_sound = make_sound([(900, 0.08, "tone")])
    miss_sound = make_sound([(220, 0.12, "tone"), (150, 0.22, "tone")])
    over_sound = make_sound([(400, 0.2, "tone"), (300, 0.2, "tone"), (200, 0.45, "tone")])


# LEVELS (difficulty levels): the player picks one, and it never changes by itself.
# speed = pixels per frame, size = square size, delay = frames between nukes
# (higher speed, smaller size and smaller delay all make it harder)
LEVELS = [
    {"speed": 5,  "size": 50, "delay": 75},    # level 1
    {"speed": 7,  "size": 42, "delay": 70},    # level 2
    {"speed": 9,  "size": 34, "delay": 65},    # level 3
    {"speed": 11, "size": 28, "delay": 60},    # level 4
    {"speed": 13, "size": 22, "delay": 50},    # level 5: the hardest
]

# One explosion sound per level: a bigger nuke gives a louder, longer, deeper boom
blast_sounds = []
if sound_ok:
    for level_info in LEVELS:
        nuke_size = level_info["size"]
        thump = 140 - nuke_size * 1.4            # size 50 -> 70 Hz (deep), size 22 -> about 109 Hz
        length = 0.15 + nuke_size * 0.005        # size 50 -> 0.40 s, size 22 -> 0.26 s
        loudness = 0.25 + nuke_size * 0.009      # size 50 -> 0.70, size 22 -> about 0.45
        blast_sounds.append(make_sound([(thump, length, "boom")], loudness))


def play(sound_name):
    if not sound_ok:
        return                                         # no sound device: the game stays silent
    if sound_name == "click":
        click_sound.play()
    elif sound_name == "blast":
        blast_sounds[selected_level].play()
    elif sound_name == "miss":
        miss_sound.play()
    elif sound_name == "over":
        over_sound.play()


pad = pygame.Rect(20, 250, 20, 100)
nukes = []          # every nuke on screen
blasts = []         # every explosion on screen: [x, y, age, nuke size]
spawn_timer = 0     # counts frames since the last nuke appeared

# Buttons
replay_button = pygame.Rect(0, 0, 200, 60)
replay_button.center = (WIDTH // 2, HEIGHT // 2)

resume_button = pygame.Rect(0, 0, 200, 60)
resume_button.center = (WIDTH // 2, HEIGHT // 2)

home_button = pygame.Rect(0, 0, 200, 60)
home_button.center = (WIDTH // 2, HEIGHT // 2 + 80)

exit_button = pygame.Rect(0, 0, 200, 60)
exit_button.center = (WIDTH // 2, HEIGHT // 2 + 160)

# One button for each level, in a row across the middle of the first screen
level_buttons = []
for i in range(len(LEVELS)):
    level_button = pygame.Rect(0, 0, 120, 60)
    level_button.center = (WIDTH // 2 + (i - 2) * 140, HEIGHT // 2)
    level_buttons.append(level_button)

pad_speed = 8
score = 0
lives = 5
selected_level = 0   # the level the player picked (0 means level 1)
state = "splash"     # "splash", "menu", "playing", "paused" or "gameover"


def spawn_nuke():
    size = LEVELS[selected_level]["size"]
    # y starts below the top bar, so nukes never cross the words
    nukes.append(pygame.Rect(WIDTH, random.randint(HUD_HEIGHT, HEIGHT - size), size, size))


def add_blast(x, y, size):
    blasts.append([x, y, 0, size])         # [x, y, age in frames, nuke size]


def draw_blasts():
    for x, y, age, size in blasts:
        t = age / 30                       # goes from 0 to 1 over 30 frames
        scale = size / 50                  # size 50 -> 1.0, size 22 -> 0.44
        radius = int((10 + t * 60) * scale)

        # fire: three circles, biggest first
        pygame.draw.circle(screen, (255, 60, 0), (int(x), int(y)), radius)
        pygame.draw.circle(screen, (255, 150, 0), (int(x), int(y)), int(radius * 0.7))
        pygame.draw.circle(screen, (255, 230, 80), (int(x), int(y)), int(radius * 0.4))

        # sparks: 12 short lines shooting outward
        spark_width = max(1, int(3 * scale))
        for i in range(12):
            angle = i * math.pi / 6
            start_pos = (int(x + math.cos(angle) * radius),
                         int(y + math.sin(angle) * radius))
            end_pos = (int(x + math.cos(angle) * (radius + (15 + t * 25) * scale)),
                       int(y + math.sin(angle) * (radius + (15 + t * 25) * scale)))
            pygame.draw.line(screen, (255, 200, 0), start_pos, end_pos, spark_width)


def reset_game():
    global score, lives, spawn_timer
    score = 0
    lives = 5
    spawn_timer = 0
    pad.y = 250
    nukes.clear()
    blasts.clear()


def draw_text(message, y, text_font=font):
    image = text_font.render(message, True, (0, 0, 0))
    screen.blit(image, image.get_rect(center=(WIDTH // 2, y)))


def draw_button(rect, label):
    if rect.collidepoint(pygame.mouse.get_pos()):
        colour = (60, 179, 113)
    else:
        colour = (34, 139, 34)
    pygame.draw.rect(screen, colour, rect)
    lines = label.split("\n")                      # "\n" starts a new line inside the button
    line_font = font if len(lines) == 1 else small_font
    line_height = line_font.get_linesize()
    top = rect.centery - line_height * len(lines) // 2
    for n, line in enumerate(lines):
        image = line_font.render(line, True, (255, 255, 255))
        screen.blit(image, image.get_rect(midtop=(rect.centerx, top + n * line_height)))


def draw_game():
    pygame.draw.rect(screen, (7, 69, 19), pad)
    for nuke in nukes:
        pygame.draw.rect(screen, (40, 20, 60), nuke)
    draw_blasts()

    # top bar for the words (drawn last so nothing covers the text)
    pygame.draw.rect(screen, (100, 170, 210), (0, 0, WIDTH, HUD_HEIGHT))
    text = font.render(f"Difficulty Level: {selected_level + 1}   Score: {score}   Lives: {lives}", True, (0, 0, 0))
    screen.blit(text, (10, 10))
    hint = small_font.render("UP / DOWN to move, P to pause  task: block the squares from going to the other side with the rec ", True, (0, 0, 0))
    screen.blit(hint, (10, 40))


SPLASH_TIME = 3000                    # how long the opening screen stays, in milliseconds
splash_start = pygame.time.get_ticks()

running = True
while running:
    # 1. Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
            if state == "playing":
                state = "paused"
                play("click")
            elif state == "paused":
                state = "playing"
                play("click")

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if state == "menu":
                for i in range(len(level_buttons)):
                    if level_buttons[i].collidepoint(event.pos):
                        selected_level = i
                        reset_game()
                        state = "playing"
                        play("click")
                if exit_button.collidepoint(event.pos):
                    running = False
                    pygame.mixer.stop()
            elif state == "paused":
                if resume_button.collidepoint(event.pos):
                    state = "playing"
                    play("click")
                elif home_button.collidepoint(event.pos):
                    state = "menu"
                    play("click")
            elif state == "gameover":
                if replay_button.collidepoint(event.pos):
                    reset_game()
                    state = "playing"
                    play("click")
                elif home_button.collidepoint(event.pos):
                    state = "menu"
                    play("click")

    screen.fill((135, 206, 235))

    # 1b. Opening screen: light blue background and a dark blue square for 3 seconds
    if state == "splash":
        elapsed = pygame.time.get_ticks() - splash_start
        angle = elapsed / 1000 * 2 * math.pi          # one full spin every second
        half = 75                                     # half of the square's side (square is 150 wide)
        corner_distance = half * math.sqrt(2)         # centre to corner
        points = []
        for corner in range(4):
            a = angle + math.pi / 4 + corner * math.pi / 2
            points.append((WIDTH // 2 + math.cos(a) * corner_distance,
                           HEIGHT // 2 + math.sin(a) * corner_distance))
        pygame.draw.polygon(screen, (10, 30, 120), points)
        if elapsed >= SPLASH_TIME:
            state = "menu"                # now "Block the Bombs!" appears

    # 2. First screen: the title and the level buttons together
    elif state == "menu":
        draw_text("Block the Bombs!", HEIGHT // 2 - 130, big_font)
        draw_text("Click a difficulty level to start", HEIGHT // 2 - 60)
        for i in range(len(level_buttons)):
            draw_button(level_buttons[i], "Difficulty\nLevel " + str(i + 1))
        draw_button(exit_button, "EXIT")
        draw_text("Exit for closing the game", exit_button.bottom + 25, small_font)

    # 3. Playing screen
    elif state == "playing":
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and pad.top > HUD_HEIGHT:
            pad.y -= pad_speed
        if keys[pygame.K_DOWN] and pad.bottom < HEIGHT:
            pad.y += pad_speed

        level = LEVELS[selected_level]

        # Spawn a new nuke every so often (the delay is constant)
        spawn_timer += 1
        if spawn_timer >= level["delay"]:
            spawn_nuke()
            spawn_timer = 0

        # Move and check every nuke at the constant speed of this level
        for nuke in nukes[:]:
            nuke.x -= level["speed"]
            if nuke.colliderect(pad):
                score += 1
                add_blast(nuke.centerx, nuke.centery, nuke.width)
                play("blast")
                nukes.remove(nuke)
            elif nuke.right < 0:
                lives -= 1
                play("miss")
                nukes.remove(nuke)

        # Blasts get older only while the game is playing, so a pause freezes them
        for blast in blasts[:]:
            blast[2] += 1
            if blast[2] > 30:
                blasts.remove(blast)

        if lives <= 0:
            state = "gameover"
            play("over")

        draw_game()

    # 4. Paused screen
    elif state == "paused":
        draw_game()
        draw_text("Paused", HEIGHT // 2 - 80, big_font)
        draw_button(resume_button, "RESUME")
        draw_button(home_button, "HOME")

    # 5. Game over screen
    elif state == "gameover":
        draw_text("Game Over!", HEIGHT // 2 - 130, big_font)
        draw_text(f"Difficulty Level {selected_level + 1}   Final score: {score}", HEIGHT // 2 - 70)
        draw_button(replay_button, "PLAY AGAIN")
        draw_button(home_button, "HOME")

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
