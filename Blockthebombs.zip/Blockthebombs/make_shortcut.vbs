' Double-click this file. It puts a "Block the Bombs" shortcut with your own icon on the Desktop.
' Keep it in the same folder as block_the_bombs.py and block_the_bombs.ico.
Set sh = CreateObject("WScript.Shell")
folder = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
desktop = sh.SpecialFolders("Desktop")

Set lnk = sh.CreateShortcut(desktop & "\Block the Bombs.lnk")
lnk.TargetPath = "cmd.exe"
lnk.Arguments = "/c pyw """ & folder & "\block_the_bombs.py"""
lnk.WorkingDirectory = folder
lnk.IconLocation = folder & "\block_the_bombs.ico"
lnk.WindowStyle = 7
lnk.Save

MsgBox "Done! Look for 'Block the Bombs' on your Desktop."
