@echo off
cd /d "%~dp0"
REM Put this file, block_the_bombs.py and block_the_bombs.ico in the same folder, then double-click.

set PY=
where py >nul 2>nul && set PY=py
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" goto nopython

echo Using: %PY%
REM pygame-ce is the community version of pygame; it works with the newest Python and the game code is the same
%PY% -m pip uninstall -y pygame
%PY% -m pip install pyinstaller pygame-ce
if errorlevel 1 goto failed

%PY% -m PyInstaller --onefile --windowed --icon=block_the_bombs.ico --name "Block the Bombs" block_the_bombs.py
if errorlevel 1 goto failed

echo.
echo Done! Your game is in the "dist" folder: dist\Block the Bombs.exe
pause
exit /b 0

:nopython
echo Python was not found on this PC. Install it from python.org (tick "Add python.exe to PATH"), then run this again.
pause
exit /b 1

:failed
echo.
echo Something went wrong. Read the red or error lines above.
pause
exit /b 1
